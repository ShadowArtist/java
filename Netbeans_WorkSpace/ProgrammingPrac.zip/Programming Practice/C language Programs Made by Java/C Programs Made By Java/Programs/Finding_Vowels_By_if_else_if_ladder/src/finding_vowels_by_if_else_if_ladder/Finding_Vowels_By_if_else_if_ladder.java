/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finding_vowels_by_if_else_if_ladder;
import java.util.Scanner;
/**
 *
 * @author RehanUsmani
 */
public class Finding_Vowels_By_if_else_if_ladder {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
    Scanner input=new Scanner(System.in);
   //ch=character 
    String ch=input.next();
    
    // here we are comparing the typed string by before by stored string
    // 
    if(ch.equals("a"))
    {
    System.out.println("it is vowel");
    }
    
    else if(ch.equals("e"))
    {
    System.out.println("it is vowel");
    }
    
     else if(ch.equals("i"))
    {
    System.out.println("it is vowel");
    }
    
     else if(ch.equals("o"))
    {
    System.out.println("it is vowel");
    }
    
     else if(ch.equals("u"))
    {
    System.out.println("it is vowel");
    }
    
    else if(ch.equals("A"))
    {
    System.out.println("it is vowel");
    }
    
     else if(ch.equals("E"))
    {
    System.out.println("it is vowel");
    }
    
     else if(ch.equals("I"))
    {
    System.out.println("it is vowel");
    }
    
     else if(ch.equals("O"))
    {
    System.out.println("it is vowel");
    }
    
     else if(ch.equals("U"))
    {
    System.out.println("it is vowel");
    }
    
     else {
     System.out.println("it is consonsnt");
     }
    
    
    }
    
}
