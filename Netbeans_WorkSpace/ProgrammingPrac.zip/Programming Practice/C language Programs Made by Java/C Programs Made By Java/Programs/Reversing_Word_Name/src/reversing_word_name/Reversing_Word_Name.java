/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package reversing_word_name;



import java.lang.*; 
/**
 *
 * @author RehanUsmani
 */
public class Reversing_Word_Name {

    /*
    
     */
    public static void main(String[] args) {
        // TODO code application logic here
   
        
        /*
    The Java.lang.StringBuffer.reverse() is an inbuilt method which is used to reverse the characters in the StringBuffer. The method causes this character sequence to be replaced by the reverse of the sequence.
Syntax :

public StringBuffer reverse()
Parameters : The method does not take any parameter .

Return Value : The method returns the StringBuffer after reversing the characters.
        
            
     */
        
        
        
        //Guide Taken From https://www.geeksforgeeks.org/stringbuffer-reverse-method-in-java/
        
        // after StringBuffer define Variable
        
     StringBuffer a = new StringBuffer("Rehan"); 
        System.out.println("String buffer = " + a); 
          
        // Here it reverses the string buffer 
        a.reverse(); 
        System.out.println("String buffer after reversing = " + a);
    
        
        
        
        
        
    }
    
}
