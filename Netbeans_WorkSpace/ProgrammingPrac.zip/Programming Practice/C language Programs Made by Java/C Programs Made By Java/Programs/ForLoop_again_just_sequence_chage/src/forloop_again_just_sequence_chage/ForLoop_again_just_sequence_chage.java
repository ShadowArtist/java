/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package forloop_again_just_sequence_chage;

/**
 *
 * @author RehanUsmani
 */
public class ForLoop_again_just_sequence_chage {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    int count;
    
    for(count=0;count<10;count++)
    {
        System.out.println("NUmbers Are :"+count); }
    
    
    System.out.println("************************************"); 
    
    
    
     for(count=0;count<10;count++)
    
        System.out.println("NUmbers Are :"+count); 
     
     //with braces and without braces answer is coming same why then why 
     // i think it is because the statement which we want to be remain in loop thats why we put braces
    
    }
    
}
