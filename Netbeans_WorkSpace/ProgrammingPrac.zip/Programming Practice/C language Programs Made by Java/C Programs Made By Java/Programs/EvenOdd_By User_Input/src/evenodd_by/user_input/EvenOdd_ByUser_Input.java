/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package evenodd_by.user_input;
import java.util.Scanner;

/**
 *
 * @author RehanUsmani
 */
public class EvenOdd_ByUser_Input {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
   
    Scanner input=new Scanner(System.in);
    
    int Enter_Number=input.nextInt();
    
    if(Enter_Number%2==0){
    System.out.println("Your Number is even");
    }
    
    else if (Enter_Number%2==1){
    System.out.println("Your Number is Odd");
    }
    
    else {
    System.out.println("Wrong Number");
    }
    
    
    }
    
}
