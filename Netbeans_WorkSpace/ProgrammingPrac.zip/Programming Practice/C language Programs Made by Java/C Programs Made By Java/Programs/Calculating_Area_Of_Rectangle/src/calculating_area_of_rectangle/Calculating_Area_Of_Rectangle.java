/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculating_area_of_rectangle;
import java.util.Scanner;
/**
 *
 * @author RehanUsmani
 */
public class Calculating_Area_Of_Rectangle {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
    Scanner  input= new Scanner(System.in);
    
    
   
    
    
    System.out.println("Enter your length");
    float length =input.nextInt();
    
     System.out.println("Enter your width");
    float width= input.nextInt();
    
    
    
    System.out.println("area of a rectangle is:"+length*width);
    }
    
}
