/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package while_loop;

/**
 *
 * @author RehanUsmani
 */
public class WHILE_LOOP {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
   
    int total=0;
    int count =0;
    
    
    
    while (count<10){
    
    
    int total_numbers=total+count;
    
  
    
    // is mentioning count++ , outside  necessary in while loop or can it be called when printing the stsetment 
    
     System.out.println(   "count = " + count++  + " Number ="+total_numbers);
    
    }
    
    
    }
    
}
