/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package new_example_of_nested_for_loop;

/**
 *
 * @author RehanUsmani
 */
public class New_Example_Of_Nested_For_Loop {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
   
    
		for(int i=0;i<=2;i++) {
			System.out.println("row = "+i);
			
			
			for(int j=0;j<=2;j++) {
				System.out.println("column = "+j);
				
			}
			
			
			
			
			
		} 
    
    
    
    }
    
}
