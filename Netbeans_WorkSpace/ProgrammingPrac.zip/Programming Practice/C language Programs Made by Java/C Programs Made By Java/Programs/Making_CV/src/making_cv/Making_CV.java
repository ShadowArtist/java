/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package making_cv;

import java.util.Scanner;
/**
 *
 * @author RehanUsmani
 */
public class Making_CV {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
   
    Scanner input=new Scanner(System.in);
    
    
    
    
    System.out.println("*******My Personal CV******");
    
    System.out.println("Name:");
    String Name=input.next();
   
    System.out.println("Father Name:");
    String Father_Name=input.next();
    
    System.out.println("Street Address:");
    String Street_Address=input.next();
    
    System.out.println("Contact Number:");
    String Contact_Number=input.next();
    
    System.out.println("Email Adress:");
    String Email_Adress=input.next();
    
    System.out.println("__________________________________");
    
    System.out.println(" Objective:");
    String Objective=input.next();
    
    
    System.out.println("__________________________________");
     System.out.println(" Acadmic Service:");
     
      System.out.println(" Degree :");
    String Degree=input.next();
    
     System.out.println(" degree Passing Year:");
    String Passing_Year=input.next();
    
    
    }
    
}
