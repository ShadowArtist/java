/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vowels_by_switch;
import java.util.Scanner;
/**
 *
 * @author RehanUsmani
 */
public class Vowels_BY_Switch {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
   
    Scanner input= new Scanner(System.in);
    
    
    String alphabet=input.next();
    
    
    switch(alphabet){
    
        case "a":
            System.out.println("It is vowel");
            break;
    
    case "e":
            System.out.println("It is vowel");
            break;
    
            
            case "i":
            System.out.println("It is vowel");
            break;
            
            
            case "o":
            System.out.println("It is vowel");
            break;
    
    case "u":
            System.out.println("It is vowel");
            break;
    
    
            case "A":
            System.out.println("It is vowel");
            break;
    
    case "E":
            System.out.println("It is vowel");
            break;
    
            
            case "I":
            System.out.println("It is vowel");
            break;
            
            
            case "O":
            System.out.println("It is vowel");
            break;
    
    case "U":
            System.out.println("It is vowel");
            break;
    
    default:
    System.out.println("It is a consonant");
    break;
    
    }
    
    
    
    
    }
    
}
