/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simple_positive_or_negative_number_finding_by_user_input;
import java.util.Scanner;
/**
 *
 * @author RehanUsmani
 */
public class Simple_positive_or_negative_number_finding_by_User_input {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
       
        
        Scanner input=new Scanner(System.in);
        
        int number=input.nextInt();
        
        
        
    
        if(number>=0){
        System.out.println("It is positive number");
        }
        
        else if(number<0){
        System.out.println("It is negative number");
        }
        
        else 
        {
            System.out.println("have you lost some where");
            System.out.println("Dear this is program only for positive and negative number");
        System.out.println("Enter positive number or negative number -_____-");
        }
    }
    
}
