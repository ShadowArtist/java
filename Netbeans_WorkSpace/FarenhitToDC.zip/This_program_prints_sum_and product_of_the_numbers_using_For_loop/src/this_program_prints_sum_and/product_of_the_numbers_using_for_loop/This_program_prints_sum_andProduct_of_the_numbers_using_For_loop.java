/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package this_program_prints_sum_and.product_of_the_numbers_using_for_loop;
import java.util.Scanner;
/**
 *
 * @author RehanUsmani
 */
public class This_program_prints_sum_andProduct_of_the_numbers_using_For_loop {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
   
    Scanner input=new Scanner(System.in);
    
    
    //without for Loop working on its for loop
    
    
    System.out.println("Enter Your First Number");
    int num1=input.nextInt();
    
    System.out.println("Enter Your Second Number");
    int num2=input.nextInt();
    


    
    int sum=num1+num2;
    int product=num1*num2;
    
    
    
    System.out.println("Sum is "+sum+" Product is "+product);
    
    
  

    
    
    }
    
}
