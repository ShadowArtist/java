/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package this_program_inputs_temperature_in_degree_fahrenheit_and_converts_it.into_degree_centigrade;

import java.util.Scanner;
/**
 *
 * @author RehanUsmani
 */


public class This_program_inputs_temperature_in_degree_Fahrenheit_and_converts_itInto_degree_Centigrade {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        
        
        //Farenheit to celcius
        
        System.out.println("Enter Temperature in Farenheit");
        float Temp_In_Farenhiet= input.nextInt();
        
        //temprature formula1
        float Temp1=(Temp_In_Farenhiet-32)*5/9;
        
        System.out.println("Temperature in Celcius is "+Temp1);
   
    
        
        
        //Celcius to farenheit
     System.out.println("Enter Temperature in Celcius");   
    float Temp_In_Celcius= input.nextInt();
    
    //temperature formula 
    float Temp2 = (Temp_In_Celcius*9/5)+32;
    
    System.out.println("Temperature In Farenheit is "+Temp2);
    }
    
}
