package array_;

public class interface2 {

}
