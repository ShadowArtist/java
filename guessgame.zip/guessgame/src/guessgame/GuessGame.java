// SEMISTER PROJECT 
//Group members 4


package guessgame;
import java.util.Scanner;

public class GuessGame {
public static void main(String[] args) {
        
   int tries = 0; // the number of tries starts from here we assigned zero because the entries you had given is nothing at begining
boolean iterated = false;
String temp = "";
String holder = "";
Scanner keyboard = new Scanner(System.in);// here keyboard is the variable of the scanner , from which we are taking input
System.out.println("*** WELCOME TO OUR WORD GUESS GME ***");
System.out.println(" ");
System.out.println("KINDLY SELECT YOUR LEVEL");
System.out.println("1.Beginner ");
System.out.println("2.Intermediate");
System.out.println("3.Professional");
System.out.println("0.Exit");
System.out.println(" ");
System.out.print("ENTER YOUR OPTION : ");


/*
Scanner keyboard = new Scanner(System .in );
Here you created an object of class scanner. The scanner class has a nextInt() function that checks if the input entered by user is an integer.

int number = keyboard.nextInt();
Look at the right side first. To access member functions of a class, we need an object.
The object is then used to call the member functions of class, as in this case, it is the nextInt() function. You can't just call nextInt() because it is a function inside class and as I said earlier, you need an object to call it, hence we created the keyboard object above this line. 


This nextInt() function has a code to only take integers. Now you got the integer. How would you see/store it? Well since its nextINT, we need an int variable to store the value. That is why we have int number.
A better way yo do this is 
int number;

which tells the compiler to set aside 32 bit for a variable we will be using. Number will contain garbage value. When you do

number = keyboard.nextInt()

You're storing the next integer value into an int variable.

and then you're displaying a number.

So in short there are three important steps you should understand.

1. Keyboard is an object of class Scanner. We use keyboard to access/use inner functions of class.

2. We call the nextInt() function of Scanner class using keyboard as:
keyboard.nextInt();

3. The above step gives us an int value. We have to do something with the value that is why we asked for it. So we need to store it in a variable to do stuffs or for future use. So 

int number = keyboard.next(); 
Does that for us.
 
I cannot explain new Scanner(System .in ); here. So, for the time-being just remember this is how objects are declared.

What are objects?

Jeff Goodell: Would you explain, in simple terms, exactly what object-oriented software is?

Steve Jobs: Objects are like people. They’re living, breathing things that have knowledge inside them about how to do things and have memory inside them so they can remember things. And rather than interacting with them at a very low level, you interact with them at a very high level of abstraction, like we’re doing right here.

Here’s an example: If I’m your laundry object, you can give me your dirty clothes and send me a message that says, “Can you get my clothes laundered, please.” I happen to know where the best laundry place in San Francisco is. And I speak English, and I have dollars in my pockets. So I go out and hail a taxicab and tell the driver to take me to this place in San Francisco. I go get your clothes laundered, I jump back in the cab, I get back here. I give you your clean clothes and say, “Here are your clean clothes.”

You have no idea how I did that. You have no knowledge of the laundry place. Maybe you speak French, and you can’t even hail a taxi. You can’t pay for one, you don’t have dollars in your pocket. Yet I knew how to do all of that. And you didn’t have to know any of it. All that complexity was hidden inside of me, and we were able to interact at a very high level of abstraction. That’s what objects are. They encapsulate complexity, and the interfaces to that complexity are high level

*/


int select=keyboard.nextInt(); 
switch(select)
{
    // guess is our array 
    // temp is used to store value in this array temporary
    // we have 4 cases  (case 0 , case 1 ,case 2 , case 3 )
      
    
    //case 0 is only for exiting the game 
    
    case 0:
        System.out.println(" ");
        	System.out.println("**** GOOD BYE **** ");
        	break;
       
                
                
                
                //case 1 = biggner level
        case 1:
        String word="apple";
        word=word.toUpperCase();// because of this line the word we will enter will come in upper case 
        System.out.println("_ p _ _ e (you have 5 chances to guess the word)");
        System.out.println(" ");
        do 
        {
        System.out.println("Enter your letter guess");
        String guess = keyboard.nextLine();
        guess=guess.toUpperCase();
        for(int i = 0; i < word.length(); i ++) {
        if (guess.equals(Character.toString(word.charAt(i)))) {
        if(!iterated)
        temp += Character.toString(word.charAt(i));
        else {
        holder = Character.toString(temp.charAt(i)).replace("-", guess);
        temp = temp.substring(0, i) + holder + temp.substring( i + 1, temp.length());
        }
        }
 else {
         if(!iterated) {
         temp += "-";
         }
         }
         }
         tries++;
         iterated = true;
         System.out.println(temp);
         if(temp.equals(word)) {
         System.out.println("You guessed correctly!"); 
         }
         }
         while (tries < 6); // case 1 lifes // tries will be incremented till when the number of tries is less than 6

        {
         System.out.println("\n\n*********************\n* SORRY YOU LOOSE *\n*********************  ");
}
break;
 








// case 2 = Intermediate level



 case 2:
     
String words="computer";  // over here the length of words are pre defined as we can see the length of words is 8 ,their are 8 letters in computer

words=words.toUpperCase(); // assigned the words in uppercase
System.out.println("_ O _ _ _ T _ _ (you have 8 chances to guess the word)");
System.out.println(" ");
do 
{
System.out.println("Enter your letter guess");
String guesss = keyboard.nextLine();
guesss=guesss.toUpperCase(); // by to Upper Case  the word that we will enter will be in caps 





for(int j = 0; j < words.length(); j ++) //above in String words are defined  this line means "j" starts from zero and increment the value untill it reaches to the length of words



{
    //here we had applied neste if else 
if (guesss.equals(Character.toString(words.charAt(j)))) // guess is our array 
{
if(!iterated)
temp += Character.toString(words.charAt(j));
else {
holder = Character.toString(temp.charAt(j)).replace("-", guesss);
temp = temp.substring(0, j) + holder + temp.substring( j + 1, temp.length());
}
} 
else 
{
if(!iterated) {
temp += "-";
}
}
}
tries++;
iterated = true;
System.out.println(temp);
if(temp.equals(words)) {
System.out.println("You guessed correctly!");}
}
        	 
while (tries < 9); // case 2 lifes // tries will be incremented till when the number of tries is less than 11
{
System.out.println("\n\n*********************\n* SORRY YOU LOOSE *\n*********************  ");
}
break;






// case 3 is of professional 
case 3:
            
String wordss="university";  // over here the length of words are pre defined as we can see the length of words is
wordss=wordss.toUpperCase();
System.out.println("_ _ I _ E _ _ _ _ Y (you have 10 chance to guess the word)");
System.out.println(" ");
do 
{
System.out.println("Enter your letter guess");
String guessss = keyboard.nextLine();
guessss=guessss.toUpperCase();
for(int j = 0; j < wordss.length(); j ++)

{
if (guessss.equals(Character.toString(wordss.charAt(j)))) {
if(!iterated)
temp += Character.toString(wordss.charAt(j));
else {
holder = Character.toString(temp.charAt(j)).replace("-", guessss);
temp = temp.substring(0, j) + holder + temp.substring( j + 1, temp.length());
}
} else {
if(!iterated) {
temp += "-";
}
}
}
tries++; // it will increment the turn unless the while loop ends and our life is over 
iterated = true;
System.out.println(temp);
if(temp.equals(wordss)) {
System.out.println("You guessed correctly!");}
}
while (tries < 11); // case 3 lifes // tries will be incremented till when the number of tries is less than 2
{
System.out.println("\n\n*********************\n* SORRY YOU LOOSE *\n*********************  ");
}
break;

     
        
        
        
   // while loop with tries have lifes if  these lifes are ended the loop will terminate      
        
        
        
        
        
    }
    
}
}
